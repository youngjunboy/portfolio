
window.onload=function() {
    
}

$(function() {
    
})