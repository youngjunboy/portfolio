let lim, title;
window.onload=function(){
    title = document.querySelector('.title')
    lim = document.querySelector('.lim');
    title.onclick=function(){
        lim.style.display='block';
        $('.lim').animate({'left':'70%'},{duration:500, easing:'easeInElastic'});
        $('.name').delay(1000).animate({'left':'100px'},{duration:500, easing:'easeInElastic'});
        $('.tel').delay(1500).animate({'left':'100px'},{duration:500, easing:'easeInElastic'});
        $('.email').delay(2000).animate({'left':'100px'},{duration:500, easing:'easeInElastic'});
    }
}